
import time, random
from datetime import datetime
from typing import Dict, Any
from core_agents import MaterialScienceAgent, MechanicalDesignAgent, ElectronicsAgent, SoftwareAgent

class CoordinatorAgent:
    def __init__(self):
        self.expert_agents = {
            "材料科学": MaterialScienceAgent(),
            "机械设计": MechanicalDesignAgent(),
            "电子工程": ElectronicsAgent(),
            "软件工程": SoftwareAgent()
        }

    def analyze(self, problem: Dict[str, Any]):
        desc = problem.get("description", "")
        tasks = {}

        if any(k in desc for k in ["材料", "性能"]):
            tasks["材料科学"] = {
                "task": "材料分析", "materials": problem.get("materials", [])
            }
        if any(k in desc for k in ["机械", "结构"]):
            tasks["机械设计"] = {
                "task": "机械设计", "constraints": problem.get("mechanical_constraints", {})
            }
        if any(k in desc for k in ["电子", "控制"]):
            tasks["电子工程"] = {
                "task": "电子系统设计", "requirements": problem.get("electronic_requirements", {})
            }
        if any(k in desc for k in ["软件", "算法"]):
            tasks["软件工程"] = {
                "task": "软件设计", "requirements": problem.get("software_requirements", {})
            }

        results = {d: self.expert_agents[d].analyze(task) for d, task in tasks.items()}

        return {
            "tasks_completed": len(tasks),
            "domain_results": results,
            "system_architecture": "分层式架构",
            "timeline_estimate": {"total_duration": random.randint(8, 16)},
            "risk_assessment": {"risk_level": "中等"},
            "recommendations": ["建议跨领域评审", "预留开发缓冲时间"]
        }

class ResearchCollaborationPlatform:
    def __init__(self):
        self.coordinator = CoordinatorAgent()
        self.active_projects = []

    def start_project(self, project_name, description, params=None):
        project = {"project_name": project_name,
                   "description": description,
                   "start_time": datetime.now().isoformat(),
                   "parameters": params or {},
                   "status": "进行中"}
        result = self.coordinator.analyze({**project, **(params or {})})
        project["analysis_result"] = result
        project["project_id"] = f"PRJ_{int(time.time()*1000)}"
        self.active_projects.append(project)
        return project

    def get_active_projects(self):
        return self.active_projects

    def generate_project_report(self, pid):
        for p in self.active_projects:
            if p["project_id"] == pid:
                r = p["analysis_result"]
                s = f"项目报告: {p['project_name']}\n完成任务: {r['tasks_completed']}\n架构: {r['system_architecture']}\n风险: {r['risk_assessment']['risk_level']}\n"
                return s
        return "未找到项目"
