
from platform_module import ResearchCollaborationPlatform
from demo import create_demo_project

if __name__ == "__main__":
    platform = create_demo_project()
    print("=== 活跃项目 ===")
    for project in platform.get_active_projects():
        print(f"- {project['project_name']} ({project['project_id']})")
    print("\n=== 项目报告 ===")
    for project in platform.get_active_projects():
        print(platform.generate_project_report(project['project_id']))
