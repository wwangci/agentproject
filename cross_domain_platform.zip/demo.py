
from platform_module import ResearchCollaborationPlatform

def create_demo_project():
    platform = ResearchCollaborationPlatform()
    p = platform.start_project(
        "智能机器人研发",
        "研发一款能够在复杂环境中自主导航的智能机器人，包括材料、电控、机械和软件设计",
        {
            "materials": ["钛合金", "碳纤维"],
            "mechanical_constraints": {"payload": 10},
            "electronic_requirements": {"power": "24V"},
            "software_requirements": {"ai": "实时处理"}
        }
    )
    return platform
